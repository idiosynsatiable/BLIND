# MANUS_CONTEXT — Shine in the Darkness (Amortized Intelligence)

## North Star
Launch an accessibility-first nonprofit website for a trade-forward fundraiser serving blind & low-vision communities.
Tone: dignified, poetic, grounded. No pity framing. No clutter.

## Brand System (hard constraints)
- Rococo-white base (warm, not sterile)
- Gilded pinstripe accents (thin, tasteful)
- Slate-grey ink for typography
- Luxury minimalism: "expensive" = restraint, spacing, materials, typography, motion (subtle), not loud bling

## UX Rules (hard constraints)
- Keyboard navigable
- Visible focus states
- Semantic headings / landmarks
- Plain language default; optional expanded details
- Avoid dark patterns and manipulative donation UX

## Content Rules
- Core line stays: “When we say ‘It was nice seeing you,’ we mean it.”
- Emphasize trade-forward as voluntary generosity (not pressure).
- Sponsors are recognized cleanly (no gaudy billboard vibe).

## Integrations (ship-ready)
- Stripe checkout for one-time donations (already implemented)
- Webhook endpoint present (extend later for CRM/email receipts/DB)

## Definition of Done
- Site builds and runs locally
- Stripe checkout works in test mode
- Lighthouse Accessibility score is high
- Copy reads like a real nonprofit (not like a template)

## Next Upgrade Paths (Phase 2+)
- CMS for stories (Sanity/Contentful) or MDX pages
- Sponsor intake form (Formspree/Resend + DB)
- Trade chain tracker (public ledger page)
- Impact dashboard and updates (audio-friendly)
