# MASTER PROMPT — Build/extend this nonprofit site (copy/paste into an app builder)

You are building a production-quality nonprofit website called **Shine in the Darkness**.

## Purpose
A trade-forward fundraiser serving blind & low-vision communities.
Tone: dignified, poetic, grounded. Absolutely no pity framing.

## Brand (hard constraints)
- Rococo white base (warm)
- Gilded pinstripe accents (thin, tasteful)
- Slate/grey typography
- Luxury minimalism: expensive = restraint + spacing + material feel, not loud bling

## UX (hard constraints)
- Accessibility-first: keyboard navigation, visible focus, semantics, high contrast
- No dark patterns for donations
- Plain language by default

## Pages (must-have)
Home, The Trade, Donate, Sponsors, About, Privacy, Terms, Accessibility.

## Integrations
- Stripe Checkout for one-time donations
- Stripe webhook endpoint for receipts/logging (extendable)

## Acceptance Criteria
- `npm run build` succeeds
- Donation flow works in Stripe test mode
- No console errors
- Clean UI, strong typographic hierarchy, generous spacing
- Lighthouse Accessibility score is high

## Do not do
- No bloated animations
- No low-contrast text
- No manipulative donation UX
