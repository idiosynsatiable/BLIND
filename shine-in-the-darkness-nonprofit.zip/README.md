# Shine in the Darkness — Nonprofit Website (Next.js + Tailwind + Stripe)

**Brand:** rococo white, gilded pinstripe, slate-grey restraint  
**Goal:** launch a clean, accessible, sponsor-ready website with donation capability.

## 1) Run locally
```bash
npm install
npm run dev
```

## 2) Required environment variables
Create `.env.local`:

```bash
APP_URL=http://localhost:3000
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

> Donation checkout uses Stripe Checkout. Webhook endpoint exists at `/api/webhook`.

## 3) Stripe setup (fast)
- Create a Stripe account (test mode is fine to start)
- Get **Secret key**
- Create a webhook endpoint: `https://YOUR_DOMAIN/api/webhook`
- Add events (minimum):
  - `checkout.session.completed`
  - `payment_intent.succeeded`
- Copy the signing secret → `STRIPE_WEBHOOK_SECRET`

## 4) Deploy
Works well on Vercel or Netlify. Set env vars in your host.

## 5) What’s in this repo
- Luxe UI: rococo white + gilded pinstripes + slate-grey
- Accessibility-first structure + focus states
- Pages: Home, Trade, Donate, Sponsors, About, Privacy, Terms, Accessibility
- Stripe checkout + webhook route

**Date packaged:** January 22, 2026
