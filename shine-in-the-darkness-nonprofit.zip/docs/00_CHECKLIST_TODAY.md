# Do-this-today checklist (end-to-end) — January 22, 2026

## Goal
Go from concept → live website + donation link + sponsor pitch assets **today**.

## 0) Name & basics (30 min)
- [ ] Decide official nonprofit name (keep: “Shine in the Darkness” or your final)
- [ ] Decide a domain (Namecheap/Cloudflare Registrar)
- [ ] Create a dedicated email inbox (Google Workspace or Proton)

## 1) Business/Nonprofit setup (do what you can today; finish paperwork after)
- [ ] Pick your state filing path (Nonprofit Corp / Charity)
- [ ] Draft a 1-page mission statement (done in `/docs/02_COPY.md`)
- [ ] Draft a simple budget bucket list:
  - Access/experiences
  - Shine kits
  - Outreach & admin

## 2) Stripe (60–90 min)
- [ ] Create Stripe account (test mode first)
- [ ] Get `STRIPE_SECRET_KEY`
- [ ] Create webhook endpoint (after deploy): `/api/webhook`
- [ ] Set webhook secret `STRIPE_WEBHOOK_SECRET`
- [ ] Confirm test donation works end-to-end

## 3) Deploy the site (45–60 min)
- [ ] Create GitHub repo
- [ ] Upload this repo
- [ ] Deploy on Vercel (fastest) or Netlify
- [ ] Set env vars in host:
  - `APP_URL`
  - `STRIPE_SECRET_KEY`
  - `STRIPE_WEBHOOK_SECRET`

## 4) Sponsor outreach assets (30–60 min)
- [ ] Copy/paste sponsor one-pager from `/docs/03_SPONSOR_ONEPAGER.md`
- [ ] Make a short list of 25 targets:
  - local boutiques
  - designers
  - barbershops/salons
  - jewelers
  - luxury resale
  - custom tailors
  - optometry clinics + vision centers
  - philanthropists/patrons

## 5) Launch post + first wave (30 min)
- [ ] Post a clean announcement (X/FB/IG)
- [ ] Send 10 sponsor emails (short + direct)
- [ ] Add a “Sponsor inquiry” email alias to the site

## 6) Proof of seriousness (same day)
- [ ] Add 3 photos/graphics (later)
- [ ] Add your personal creator story (already on About page)
- [ ] Add “Transparency” section (can be a page tomorrow)

**Finish Line Today:** live site + working donation checkout + sponsor pitch copy + outreach list started.
