# Website checklist — everything needed (explained)

## Pages (must-have)
- Home: mission + CTA
- The Trade: how it works, where funds go
- Donate: one-time and monthly (monthly can be Phase 2)
- Sponsors: tiers + contact
- About: nonprofit story + creator story
- Accessibility statement
- Privacy + Terms (starter text)

## UX/UI (must-have)
- Clear hierarchy, plenty of whitespace
- Strong contrast and readable font sizing
- Keyboard navigation + visible focus outlines
- Skip link
- No manipulative donation patterns

## Trust signals (high leverage)
- Domain-based email address
- Clear “where funds go”
- Simple transparency (even if minimal at first)
- Sponsor logos (only if real and approved)

## Integrations (current)
- Stripe Checkout for one-time donations ✅
- Stripe webhook endpoint ✅

## Integrations (recommended next)
- Email provider for receipts and outreach (Resend/Mailgun)
- Sponsor inquiry form (Formspree) + spam protection
- Analytics (privacy-respecting): Plausible or Cloudflare Web Analytics
- CMS for stories and updates (Sanity/MDX)

## Compliance notes (not legal advice)
- If soliciting donations publicly, your state may require charity registration.
- Add counsel-reviewed Privacy/Terms when scaling.
- Keep clear records and publish impact updates in accessible formats.
