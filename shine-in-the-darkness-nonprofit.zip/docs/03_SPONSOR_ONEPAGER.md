# Sponsor One-Pager — Shine in the Darkness

## What it is
A trade-forward fundraiser for blind & low-vision communities — designed to be dignified, participatory, and transparent.

## Why it works
People voluntarily “trade forward” with something more meaningful because the mission resonates.
The chain becomes a story of generosity, and the outcomes become direct support.

## What sponsors provide
- Cash support for the next trade steps and direct assistance
- In-kind contributions: elegant clothing, accessories, experiences, services
- “Shine kits”: high-quality essentials curated for dignity and presence

## What sponsors receive
- Tasteful recognition (logo + short blurb + link)
- Public alignment with accessibility and dignity-first design
- Accessible impact updates (screen-reader friendly; audio optional)

## Tiers (suggested)
- Gilded Patron: $5,000+
- Pinstripe Sponsor: $1,000+
- Craft Ally: In-kind support

## Contact
Use your official nonprofit email and domain.
