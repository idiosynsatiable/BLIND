# Site copy (editable)

## Hero headline
When we say “It was nice seeing you,” we mean it.

## One-liner
A trade-forward fundraiser that converts small beginnings into access, dignity, and experiences for blind & low-vision communities.

## Short mission
We trade something small forward into something extraordinary — then turn that momentum into funding for experiences, “shine kits,” and community support.

## Donation framing
This is not pity. This is participation. Your support funds access and dignity — cleanly, transparently, and with respect.

## Sponsor framing
Sponsors help scale the chain. We keep recognition tasteful: clean logo, short blurb, and a link — luxury without loudness.
