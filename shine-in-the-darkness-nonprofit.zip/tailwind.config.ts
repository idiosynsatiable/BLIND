import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        rococo: {
          50: "#FCFBF9",
          100: "#F7F4EE",
          200: "#EFE7D8",
          300: "#E4D5BA",
          400: "#D3BC91",
          500: "#C3A46B"
        },
        gild: {
          50: "#FFF9E6",
          100: "#FFF1C2",
          200: "#FFE48A",
          300: "#FFD24D",
          400: "#FFC21A",
          500: "#E6A800"
        },
        slateink: {
          50: "#F5F6F8",
          100: "#ECEFF3",
          200: "#D6DCE7",
          300: "#B6C0D4",
          400: "#8A9AB9",
          500: "#61739B",
          600: "#4A5A7E",
          700: "#394660",
          800: "#2A3448",
          900: "#1D2433"
        }
      },
      boxShadow: {
        luxe: "0 18px 50px rgba(29,36,51,0.10), 0 2px 10px rgba(29,36,51,0.06)"
      },
      backgroundImage: {
        "pinstripe": "repeating-linear-gradient(135deg, rgba(230,168,0,0.10) 0, rgba(230,168,0,0.10) 2px, rgba(29,36,51,0.02) 2px, rgba(29,36,51,0.02) 8px)"
      },
      borderRadius: {
        "2xl": "1.25rem"
      }
    }
  },
  plugins: []
} satisfies Config;
