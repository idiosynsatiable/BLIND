import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

export default function TermsPage() {
  return (
    <Container className="py-14">
      <Section eyebrow="Plain-language" title="Terms">
        <p className="text-sm">
          By using this website, you agree not to misuse it or attempt to disrupt it.
          Donations are voluntary. If you have questions about a donation, contact us.
        </p>
        <p className="mt-4 text-xs text-slateink-700">
          Replace this page with counsel-reviewed terms before major fundraising.
        </p>
      </Section>
    </Container>
  );
}
