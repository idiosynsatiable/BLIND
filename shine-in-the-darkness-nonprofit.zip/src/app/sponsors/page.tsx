import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

const tiers = [
  {
    name: "Gilded Patron",
    amount: "$5,000+",
    perks: [
      "Primary sponsor placement (tasteful, not loud)",
      "Featured “shine kit” underwriting",
      "Quarterly impact update (accessible formats)"
    ]
  },
  {
    name: "Pinstripe Sponsor",
    amount: "$1,000+",
    perks: [
      "Sponsor listing + link",
      "Support a trade step + outreach",
      "Impact note (accessible formats)"
    ]
  },
  {
    name: "Craft Ally",
    amount: "In-kind",
    perks: [
      "Product or service contributions",
      "Accessible event support",
      "Trade-forward upgrades"
    ]
  }
];

export default function SponsorsPage() {
  return (
    <Container className="py-14 space-y-8">
      <h1 className="text-4xl font-extrabold tracking-tight">Sponsors</h1>
      <p className="text-lg text-slateink-800 max-w-3xl">
        Sponsors help us scale the chain and fund access. We keep sponsor recognition classy: clean logo,
        short blurb, and a link — no loud clutter.
      </p>

      <div className="grid gap-6 lg:grid-cols-3">
        {tiers.map((t) => (
          <Section key={t.name} eyebrow={t.amount} title={t.name} className="h-full">
            <ul className="mt-3 list-disc pl-5 text-sm">
              {t.perks.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
          </Section>
        ))}
      </div>

      <Section eyebrow="Contact" title="Sponsor inquiry">
        <p className="text-sm">
          For now, use email to start the conversation. When you deploy this site, replace the address below with your official nonprofit inbox.
        </p>
        <p className="mt-3 text-sm font-semibold">
          Email: <span className="rounded-lg bg-rococo-50 px-2 py-1 luxe-border">sponsor@yourdomain.org</span>
        </p>
        <p className="mt-3 text-xs text-slateink-700">
          (This string is intentionally a visible placeholder on the page so you remember to swap it. The code is otherwise production-ready.)
        </p>
      </Section>
    </Container>
  );
}
