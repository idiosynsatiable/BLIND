import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

export default function PrivacyPage() {
  return (
    <Container className="py-14">
      <Section eyebrow="Plain-language" title="Privacy policy">
        <p className="text-sm">
          We collect the minimum required to run donations and keep the site secure.
          Payments are processed by Stripe. We do not store your card details on our servers.
        </p>
        <p className="mt-4 text-sm">
          If you contact us by email, we’ll use your message only to respond.
          We do not sell personal information.
        </p>
        <p className="mt-4 text-xs text-slateink-700">
          Replace this page with counsel-reviewed language before major fundraising.
          This starter text is designed to be readable and honest while you launch.
        </p>
      </Section>
    </Container>
  );
}
