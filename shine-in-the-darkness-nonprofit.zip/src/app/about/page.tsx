import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Badge } from "@/components/Badge";

export default function AboutPage() {
  return (
    <Container className="py-14 space-y-10">
      <div className="space-y-4">
        <Badge>About the nonprofit</Badge>
        <h1 className="text-4xl font-extrabold tracking-tight">About</h1>
        <p className="text-lg text-slateink-800 max-w-3xl">
          Shine in the Darkness is a trade-forward fundraiser built on a simple truth:
          sometimes “seeing” is not a casual phrase — it’s a rare, meaningful event.
          We convert small beginnings into real funding and real access for blind and low-vision communities.
        </p>
      </div>

      <Section eyebrow="About the Creator" title="Idiosynsatiable — building dignity like it’s engineering">
        <p>
          The creator built this project from lived reality, not a marketing brainstorm.
          Losing vision changes what “luxury” means: it becomes less about showing off and more about <strong>craft</strong>,
          <strong> intention</strong>, and <strong>how something makes you feel</strong> when you can’t rely on a perfect view.
        </p>
        <p className="mt-4">
          This fundraiser is designed like a system: small inputs, compounding outcomes, and transparency.
          The aesthetic is rococo-white restraint with gilded pinstripes — a visual way of saying:
          <em> you deserve beautiful things without needing to justify it.</em>
        </p>
        <p className="mt-4 text-sm text-slateink-700">
          The goal is not pity. The goal is participation — and a world where people with low vision still get to shine,
          on their own terms.
        </p>
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Section eyebrow="Values" title="What we stand for">
          <ul className="list-disc pl-5 text-sm">
            <li><strong>Dignity-first</strong>: no pity framing, no “inspiration porn,” no exploitation.</li>
            <li><strong>Accessible by default</strong>: structure, contrast, focus states, and plain language.</li>
            <li><strong>Transparency</strong>: clear accounting, clear outcomes, clear reporting.</li>
            <li><strong>Beauty matters</strong>: craftsmanship and elegance are not “extra.” They are human.</li>
          </ul>
        </Section>
        <Section eyebrow="Operations" title="How we run">
          <ul className="list-disc pl-5 text-sm">
            <li>Public trade-forward chain for upgrades.</li>
            <li>Funding routed into direct support categories.</li>
            <li>Partnerships with brands and patrons for high-quality in-kind contributions.</li>
            <li>Accessible impact updates (screen-reader friendly + optional audio).</li>
          </ul>
        </Section>
      </div>
    </Container>
  );
}
