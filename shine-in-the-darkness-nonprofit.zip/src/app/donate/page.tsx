"use client";

import * as React from "react";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Button } from "@/components/Button";

type Amount = 2500 | 5000 | 10000 | 25000;

export default function DonatePage() {
  const [loading, setLoading] = React.useState<Amount | null>(null);

  async function startCheckout(amount: Amount) {
    setLoading(amount);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ amount })
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as { url: string };
      window.location.href = data.url;
    } catch (e: any) {
      alert(e?.message ?? "Checkout failed.");
      setLoading(null);
    }
  }

  return (
    <Container className="py-14 space-y-8">
      <h1 className="text-4xl font-extrabold tracking-tight">Donate</h1>
      <p className="text-lg text-slateink-800 max-w-3xl">
        One-time donations fund the next trade step, outreach, and direct support for blind & low-vision access and experiences.
        Monthly giving can be added after Stripe setup (included in this repo).
      </p>

      <Section eyebrow="One-time support" title="Choose an amount">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {([
            { amount: 2500 as const, label: "$25" },
            { amount: 5000 as const, label: "$50" },
            { amount: 10000 as const, label: "$100" },
            { amount: 25000 as const, label: "$250" }
          ]).map((a) => (
            <Button
              key={a.amount}
              onClick={() => startCheckout(a.amount)}
              disabled={loading !== null}
              className="w-full"
            >
              {loading === a.amount ? "Redirecting…" : a.label}
            </Button>
          ))}
        </div>
        <p className="mt-4 text-sm text-slateink-700">
          Payments are processed securely by Stripe. This project reads Stripe keys from environment variables — no keys are stored in code.
        </p>
      </Section>

      <Section eyebrow="Sponsorship" title="Prefer to sponsor?">
        <p className="text-sm">
          Sponsors can contribute cash, products, services, or “shine kits.” We keep the sponsor spotlight tasteful — clean logo, short blurb, and a link.
        </p>
        <div className="mt-4">
          <a className="font-semibold underline" href="/sponsors">View sponsorship options</a>
        </div>
      </Section>
    </Container>
  );
}
