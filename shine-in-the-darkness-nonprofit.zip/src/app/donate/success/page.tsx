import Link from "next/link";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

export default function SuccessPage() {
  return (
    <Container className="py-14">
      <Section eyebrow="Thank you" title="Donation received">
        <p className="text-sm">
          Your support fuels the next step in the chain. That’s not just money — that’s dignity and access.
        </p>
        <div className="mt-5 flex gap-4 text-sm font-semibold">
          <Link className="underline" href="/trade">See the concept</Link>
          <Link className="underline" href="/">Back home</Link>
        </div>
      </Section>
    </Container>
  );
}
