import Link from "next/link";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

export default function CancelPage() {
  return (
    <Container className="py-14">
      <Section eyebrow="No worries" title="Checkout canceled">
        <p className="text-sm">
          Nothing was charged. If you want to try again, we’ll be right here.
        </p>
        <div className="mt-5 flex gap-4 text-sm font-semibold">
          <Link className="underline" href="/donate">Donate</Link>
          <Link className="underline" href="/">Home</Link>
        </div>
      </Section>
    </Container>
  );
}
