import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

export default function AccessibilityPage() {
  return (
    <Container className="py-14 space-y-8">
      <h1 className="text-4xl font-extrabold tracking-tight">Accessibility</h1>

      <Section eyebrow="Commitment" title="Accessibility-first">
        <p className="text-sm">
          This project exists because accessibility is not optional.
          We design for keyboard navigation, visible focus, strong contrast, and clear information structure.
        </p>
      </Section>

      <Section eyebrow="Standards" title="What we support">
        <ul className="list-disc pl-5 text-sm">
          <li>Semantic headings and landmarks for screen readers</li>
          <li>Skip-to-content link</li>
          <li>High-contrast color palette with restraint</li>
          <li>Visible focus outlines and keyboard-friendly navigation</li>
          <li>Plain language defaults, with optional expanded detail</li>
        </ul>
      </Section>

      <Section eyebrow="Feedback" title="Report an issue">
        <p className="text-sm">
          If something is hard to use, we want to fix it. Email your feedback and include:
          device, browser, and what you were trying to do.
        </p>
      </Section>
    </Container>
  );
}
