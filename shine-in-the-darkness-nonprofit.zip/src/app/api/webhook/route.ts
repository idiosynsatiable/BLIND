import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import Stripe from "stripe";

function requiredEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

export async function POST(req: Request) {
  const sig = req.headers.get("stripe-signature");
  if (!sig) return new NextResponse("Missing stripe-signature header.", { status: 400 });

  const secret = requiredEnv("STRIPE_WEBHOOK_SECRET");
  const rawBody = await req.text();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, secret);
  } catch (err: any) {
    return new NextResponse(`Webhook signature verification failed: ${err?.message ?? "Unknown error"}`, { status: 400 });
  }

  // Minimal, safe handling. Extend to store events in a DB if desired.
  switch (event.type) {
    case "checkout.session.completed":
      break;
    case "payment_intent.succeeded":
      break;
    default:
      break;
  }

  return NextResponse.json({ received: true });
}
