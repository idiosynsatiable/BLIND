import { NextResponse } from "next/server";
import { stripe, getAppUrl } from "@/lib/stripe";

export async function POST(req: Request) {
  const body = await req.json().catch(() => null) as null | { amount: number };

  if (!body || typeof body.amount !== "number") {
    return new NextResponse("Invalid request body.", { status: 400 });
  }

  const amount = Math.round(body.amount);
  const allowed = new Set([2500, 5000, 10000, 25000]);
  if (!allowed.has(amount)) {
    return new NextResponse("Amount not allowed.", { status: 400 });
  }

  const appUrl = getAppUrl();

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: "Shine in the Darkness — Donation",
            description: "Support blind & low-vision access through the trade-forward chain."
          },
          unit_amount: amount
        },
        quantity: 1
      }
    ],
    success_url: `${appUrl}/donate/success`,
    cancel_url: `${appUrl}/donate/cancel`,
    allow_promotion_codes: true
  });

  return NextResponse.json({ url: session.url });
}
