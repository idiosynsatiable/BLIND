import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import Link from "next/link";

export default function TradePage() {
  return (
    <Container className="py-14 space-y-8">
      <h1 className="text-4xl font-extrabold tracking-tight">The Trade</h1>
      <p className="text-lg text-slateink-800 max-w-3xl">
        We start with something small and trade it forward. Each upgrade is voluntary — a public chain of dignity and generosity.
        The momentum becomes funding for blind and low-vision access to elegance, craftsmanship, and experiences that are too often kept out of reach.
      </p>

      <Section eyebrow="Mechanic" title="Trade-forward, not transactional">
        <ul className="list-disc pl-5 text-sm">
          <li>We begin with a symbolic starter item (often a coin or small token).</li>
          <li>Community members “trade forward” by offering an upgrade — not because it’s required, but because it’s meaningful.</li>
          <li>We document the chain and convert outcomes into direct support: access, experiences, and community funding.</li>
          <li>Nothing is framed as pressure. Every upgrade is gratitude-driven.</li>
        </ul>
      </Section>

      <Section eyebrow="Outcomes" title="Where the money and value go">
        <div className="grid gap-6 sm:grid-cols-2 text-sm">
          <div className="rounded-2xl bg-rococo-50 p-5 luxe-border">
            <div className="font-extrabold">Access & Experiences</div>
            <p className="mt-2 text-slateink-800">
              Tickets, guided experiences, accessible events, and moments designed with sensory respect.
            </p>
          </div>
          <div className="rounded-2xl bg-rococo-50 p-5 luxe-border">
            <div className="font-extrabold">“Shine Kits”</div>
            <p className="mt-2 text-slateink-800">
              Tasteful luxury essentials: clothing, accessories, and high-quality items that signal dignity — not charity.
            </p>
          </div>
        </div>
      </Section>

      <div className="flex gap-3">
        <Link href="/donate" className="rounded-2xl bg-slateink-900 px-5 py-3 text-sm font-semibold text-rococo-50 shadow-luxe">
          Fund the next step
        </Link>
        <Link href="/sponsors" className="rounded-2xl bg-rococo-100 px-5 py-3 text-sm font-semibold text-slateink-900 luxe-border">
          Sponsor this chain
        </Link>
      </div>
    </Container>
  );
}
