import Link from "next/link";
import { Container } from "@/components/Container";
import { Badge } from "@/components/Badge";
import { Section } from "@/components/Section";
import { site } from "@/lib/site";

export default function HomePage() {
  return (
    <Container className="py-14">
      <div className="grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-start">
        <div className="space-y-6">
          <Badge>Trade-forward fundraiser · Blind & low-vision access</Badge>
          <h1 className="text-4xl font-extrabold tracking-tight text-slateink-900 sm:text-5xl">
            When we say <span className="underline decoration-gild-300/70 underline-offset-8">“It was nice seeing you”</span>,
            we mean it.
          </h1>
          <p className="text-lg leading-relaxed text-slateink-800">
            {site.missionShort}
          </p>

          <div className="flex flex-wrap gap-3">
            <Link
              href="/trade"
              className="rounded-2xl bg-slateink-900 px-5 py-3 text-sm font-semibold text-rococo-50 shadow-luxe hover:translate-y-[-1px] active:translate-y-0"
            >
              Learn how the trade works
            </Link>
            <Link
              href="/donate"
              className="rounded-2xl bg-rococo-100 px-5 py-3 text-sm font-semibold text-slateink-900 luxe-border hover:bg-rococo-200"
            >
              Donate or sponsor
            </Link>
          </div>

          <div className="rounded-2xl bg-pinstripe p-5 luxe-border shadow-luxe">
            <div className="rounded-2xl bg-rococo-50 p-5">
              <p className="text-sm font-semibold text-slateink-900">
                Our vibe: rococo white, gilded pinstripes, slate-grey restraint — luxury without loudness.
              </p>
              <p className="mt-2 text-sm text-slateink-700">
                Accessibility is not a “feature.” It’s the foundation: contrast, typography, focus states,
                screen-reader structure, and an audio-first writing style.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Section eyebrow="Why it matters" title="Dignity-first access to design & craftsmanship">
            <p>
              A lot of fundraisers aim for pity. We aim for <strong>participation</strong>.
              The trade-forward mechanic is a public chain of generosity: the value rises because people choose to lift it.
            </p>
            <ul className="mt-4 list-disc pl-5 text-sm text-slateink-800">
              <li>Funds go to experiences, access, and community support for blind & low-vision people.</li>
              <li>Donations can be one-time or monthly.</li>
              <li>Sponsors can contribute products, services, or cash — and receive a clean, tasteful spotlight.</li>
            </ul>
          </Section>

          <Section eyebrow="Quick start" title="3 ways to help today">
            <ol className="list-decimal pl-5 text-sm">
              <li><strong>Donate</strong> (one-time or monthly) to fund the next trade step and outreach.</li>
              <li><strong>Offer an upgrade</strong>: trade an item forward with something more meaningful.</li>
              <li><strong>Sponsor</strong>: provide a featured “shine kit” (luxury essentials + experience support).</li>
            </ol>
            <div className="mt-5 flex gap-3">
              <Link className="font-semibold underline" href="/donate">Donate</Link>
              <Link className="font-semibold underline" href="/sponsors">Sponsor info</Link>
            </div>
          </Section>
        </div>
      </div>
    </Container>
  );
}
