export const site = {
  name: "Shine in the Darkness",
  tagline: "Luxury access, dignity first — a trade-forward fundraiser for blind & low-vision communities.",
  missionShort:
    "We trade a small beginning forward into something extraordinary — then convert that momentum into funding, access, and experiences for blind and low-vision people.",
  creatorName: "Idiosynsatiable",
  year: new Date().getFullYear()
};
