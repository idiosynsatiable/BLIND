import { cn } from "@/lib/cn";

export function Section({
  title,
  eyebrow,
  children,
  className
}: {
  title: string;
  eyebrow?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-2xl bg-rococo-100/60 p-6 sm:p-10 shadow-luxe luxe-border", className)}>
      {eyebrow ? (
        <div className="text-xs font-extrabold tracking-widest text-slateink-700">{eyebrow}</div>
      ) : null}
      <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-slateink-900">{title}</h2>
      <div className="mt-4 text-slateink-800 leading-relaxed">{children}</div>
    </section>
  );
}
