import Link from "next/link";
import { Container } from "@/components/Container";
import { site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-slateink-200/60 bg-rococo-50">
      <Container className="py-10">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <div className="text-sm font-extrabold tracking-tight">{site.name}</div>
            <div className="text-xs text-slateink-700">
              © {site.year} {site.name}. Built with accessibility-first intent.
            </div>
          </div>

          <div className="flex flex-wrap gap-4 text-sm font-semibold text-slateink-800">
            <Link className="hover:underline" href="/privacy">Privacy</Link>
            <Link className="hover:underline" href="/terms">Terms</Link>
            <Link className="hover:underline" href="/accessibility">Accessibility</Link>
          </div>
        </div>
      </Container>
    </footer>
  );
}
