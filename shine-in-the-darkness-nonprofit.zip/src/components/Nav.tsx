import Link from "next/link";
import { Container } from "@/components/Container";
import { site } from "@/lib/site";

const links = [
  { href: "/trade", label: "The Trade" },
  { href: "/sponsors", label: "Sponsors" },
  { href: "/donate", label: "Donate" },
  { href: "/about", label: "About" }
];

export function Nav() {
  return (
    <header className="sticky top-0 z-50 bg-rococo-50/80 backdrop-blur luxe-border">
      <Container className="flex items-center justify-between py-4">
        <Link href="/" className="group inline-flex items-center gap-3">
          <span className="h-9 w-9 rounded-2xl bg-pinstripe luxe-border shadow-luxe" aria-hidden />
          <span className="text-sm font-extrabold tracking-tight text-slateink-900">
            {site.name}
          </span>
        </Link>

        <nav className="hidden items-center gap-1 sm:flex" aria-label="Primary">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="rounded-2xl px-4 py-2 text-sm font-semibold text-slateink-800 hover:bg-slateink-100 focus-visible:outline-none"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <Link
          href="/donate"
          className="rounded-2xl bg-slateink-900 px-4 py-2 text-sm font-semibold text-rococo-50 shadow-luxe hover:translate-y-[-1px] active:translate-y-0"
        >
          Support
        </Link>
      </Container>
    </header>
  );
}
