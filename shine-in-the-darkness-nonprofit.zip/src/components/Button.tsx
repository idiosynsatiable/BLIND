"use client";

import * as React from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "ghost" | "subtle";

export function Button(
  props: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }
) {
  const { className, variant = "primary", ...rest } = props;

  const base =
    "inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold transition focus-visible:outline-none disabled:opacity-60 disabled:cursor-not-allowed";
  const styles: Record<Variant, string> = {
    primary:
      "bg-slateink-900 text-rococo-50 shadow-luxe hover:translate-y-[-1px] hover:shadow-luxe active:translate-y-0",
    ghost:
      "bg-transparent text-slateink-900 hover:bg-slateink-100 luxe-border",
    subtle:
      "bg-rococo-100 text-slateink-900 hover:bg-rococo-200 luxe-border"
  };

  return <button className={cn(base, styles[variant], className)} {...rest} />;
}
