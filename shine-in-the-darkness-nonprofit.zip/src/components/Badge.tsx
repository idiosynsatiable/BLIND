import { cn } from "@/lib/cn";

export function Badge({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full bg-gild-100 px-3 py-1 text-xs font-semibold tracking-wide text-slateink-900 luxe-border",
        className
      )}
    >
      {children}
    </span>
  );
}
